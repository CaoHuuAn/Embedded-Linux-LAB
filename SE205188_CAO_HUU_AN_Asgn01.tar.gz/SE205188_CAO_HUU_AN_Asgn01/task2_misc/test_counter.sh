#!/bin/sh

MODULE="/lib/modules/counter_driver.ko"
DEVICE="/dev/counter"
PROC="/proc/counter_info"

echo "========================================"
echo " COUNTER MISC DRIVER TEST"
echo "========================================"

echo "[1] Loading counter_driver..."
insmod "$MODULE" || {
    echo "[FAIL] Cannot load counter_driver"
    exit 1
}

echo "[OK] Driver loaded"

echo
echo "[2] Checking misc device..."

if [ -e "$DEVICE" ]; then
    echo "[OK] $DEVICE already exists"
else
    if [ -f /proc/misc ]; then
        MINOR=$(grep "counter" /proc/misc | awk '{print $1}')
    fi

    if [ -z "$MINOR" ]; then
        echo "[FAIL] Cannot find counter minor number"
        rmmod counter_driver
        exit 1
    fi

    echo "[INFO] counter minor = $MINOR"

    mknod "$DEVICE" c 10 "$MINOR" || {
        echo "[FAIL] Cannot create $DEVICE"
        rmmod counter_driver
        exit 1
    }

    chmod 666 "$DEVICE"
    echo "[OK] $DEVICE created"
fi

echo
echo "[3] Checking /proc/counter_info..."

if [ -e "$PROC" ]; then
    echo "[OK] $PROC exists"
else
    echo "[FAIL] $PROC does not exist"
    rmmod counter_driver
    exit 1
fi

echo
echo "[4] Initial counter read..."

VALUE=$(cat "$DEVICE")

if [ "$VALUE" = "0" ]; then
    echo "[OK] First read = 0"
else
    echo "[FAIL] Expected 0, got: $VALUE"
    rmmod counter_driver
    exit 1
fi

echo
echo "[5] Testing auto-increment..."

VALUE=$(cat "$DEVICE")

if [ "$VALUE" = "1" ]; then
    echo "[OK] Second read = 1"
else
    echo "[FAIL] Expected 1, got: $VALUE"
    rmmod counter_driver
    exit 1
fi

echo
echo "[6] Testing WRITE = 100..."

echo 100 > "$DEVICE" || {
    echo "[FAIL] Write 100 failed"
    rmmod counter_driver
    exit 1
}

VALUE=$(cat "$DEVICE")

if [ "$VALUE" = "100" ]; then
    echo "[OK] Read after write 100 = 100"
else
    echo "[FAIL] Expected 100, got: $VALUE"
    rmmod counter_driver
    exit 1
fi

echo
echo "[7] Testing reset WRITE = 0..."

echo 0 > "$DEVICE" || {
    echo "[FAIL] Reset failed"
    rmmod counter_driver
    exit 1
}

VALUE=$(cat "$DEVICE")

if [ "$VALUE" = "0" ]; then
    echo "[OK] Read after reset = 0"
else
    echo "[FAIL] Expected 0, got: $VALUE"
    rmmod counter_driver
    exit 1
fi

echo
echo "[8] Testing negative value..."

if echo -1 > "$DEVICE" 2>/dev/null; then
    echo "[FAIL] Negative value was accepted"
    rmmod counter_driver
    exit 1
else
    echo "[OK] Negative value rejected with -EINVAL"
fi

echo
echo "[9] Testing non-numeric value..."

if echo abc > "$DEVICE" 2>/dev/null; then
    echo "[FAIL] Non-numeric value was accepted"
    rmmod counter_driver
    exit 1
else
    echo "[OK] Non-numeric value rejected with -EINVAL"
fi

echo
echo "[10] Testing cat does not loop..."

timeout 2 cat "$DEVICE" > /tmp/counter_cat_test.txt

if [ $? -eq 124 ]; then
    echo "[FAIL] cat appears to loop"
    rmmod counter_driver
    exit 1
else
    echo "[OK] cat completed normally"
fi

echo "[INFO] cat output:"
cat /tmp/counter_cat_test.txt

echo
echo "[11] Reading /proc/counter_info..."

cat "$PROC"

echo
echo "[12] Unloading counter_driver..."

rmmod counter_driver || {
    echo "[FAIL] rmmod failed"
    exit 1
}

echo "[OK] Driver unloaded"

echo
echo "========================================"
echo " COUNTER TEST COMPLETE"
echo "========================================"

exit 0
