#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/miscdevice.h>
#include <linux/uaccess.h>
#include <linux/atomic.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/kstrtox.h>

#define DEVICE_NAME "counter"
#define PROC_NAME   "counter_info"
#define COUNTER_INPUT_SIZE 32

static atomic_t counter;
static atomic_t total_reads;
static atomic_t total_writes;

static ssize_t counter_read(struct file *file,
                            char __user *buf,
                            size_t count,
                            loff_t *ppos)
{
    char data[32];
    int len;
    int value;

    if (*ppos > 0)
        return 0;

    value = atomic_read(&counter);

    len = scnprintf(data, sizeof(data), "%d\n", value);

    if (count < len)
        return -EINVAL;

    if (copy_to_user(buf, data, len))
        return -EFAULT;

    atomic_inc(&counter);
    atomic_inc(&total_reads);

    *ppos += len;

    pr_info("counter_driver: read value=%d\n", value);

    return len;
}

static ssize_t counter_write(struct file *file,
                             const char __user *buf,
                             size_t count,
                             loff_t *ppos)
{
    char input[COUNTER_INPUT_SIZE];
    int value;
    int ret;

    if (count == 0)
        return 0;

    if (count >= sizeof(input))
        return -EINVAL;

    if (copy_from_user(input, buf, count))
        return -EFAULT;

    input[count] = '\0';

    ret = kstrtoint(input, 10, &value);
    if (ret)
        return -EINVAL;

    if (value < 0)
        return -EINVAL;

    atomic_set(&counter, value);
    atomic_inc(&total_writes);

    pr_info("counter_driver: write value=%d\n", value);

    return count;
}

static int counter_proc_show(struct seq_file *m, void *v)
{
    seq_printf(m, "Counter current value: %d\n",
               atomic_read(&counter));

    seq_printf(m, "Total reads/increments: %d\n",
               atomic_read(&total_reads));

    seq_printf(m, "Total writes/resets: %d\n",
               atomic_read(&total_writes));

    return 0;
}

static int counter_proc_open(struct inode *inode, struct file *file)
{
    return single_open(file, counter_proc_show, NULL);
}

static const struct proc_ops counter_proc_ops = {
    .proc_open    = counter_proc_open,
    .proc_read    = seq_read,
    .proc_lseek   = seq_lseek,
    .proc_release = single_release,
};

static const struct file_operations counter_fops = {
    .owner  = THIS_MODULE,
    .read   = counter_read,
    .write  = counter_write,
};

static struct miscdevice counter_misc_device = {
    .minor = MISC_DYNAMIC_MINOR,
    .name  = DEVICE_NAME,
    .fops  = &counter_fops,
    .mode  = 0666,
};

static int __init counter_driver_init(void)
{
    int ret;

    atomic_set(&counter, 0);
    atomic_set(&total_reads, 0);
    atomic_set(&total_writes, 0);

    ret = misc_register(&counter_misc_device);
    if (ret) {
        pr_err("counter_driver: misc_register failed: %d\n", ret);
        return ret;
    }

    if (!proc_create(PROC_NAME, 0444, NULL, &counter_proc_ops)) {
        misc_deregister(&counter_misc_device);
        pr_err("counter_driver: proc_create failed\n");
        return -ENOMEM;
    }

    pr_info("counter_driver: loaded, /dev/%s, major=10, minor=%d\n",
            DEVICE_NAME, counter_misc_device.minor);

    return 0;
}

static void __exit counter_driver_exit(void)
{
    remove_proc_entry(PROC_NAME, NULL);
    misc_deregister(&counter_misc_device);

    pr_info("counter_driver: unloaded\n");
}

module_init(counter_driver_init);
module_exit(counter_driver_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("CAO HỮU AN - SE205188");
MODULE_DESCRIPTION("Assignment 01 misc counter device driver");
