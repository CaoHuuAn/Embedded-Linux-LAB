#!/bin/sh

MODULE="/lib/modules/asgn1_driver.ko"
DEVICE="/dev/asgn1"
MAJOR=241
MINOR=0

echo "========================================"
echo " ASGN1 IOCTL DRIVER TEST"
echo "========================================"

echo
echo "[1] Loading driver..."

if insmod "$MODULE"; then
    echo "[OK] Driver loaded"
else
    echo "[ERROR] Failed to load driver"
    exit 1
fi

echo
echo "[2] Creating device node..."

if [ ! -e "$DEVICE" ]; then
    mknod "$DEVICE" c "$MAJOR" "$MINOR"
fi

chmod 666 "$DEVICE"

if [ -c "$DEVICE" ]; then
    echo "[OK] Device $DEVICE created"
else
    echo "[ERROR] Failed to create $DEVICE"
    rmmod asgn1_driver 2>/dev/null
    exit 1
fi

echo
echo "[3] Running userspace ioctl test..."

if /usr/bin/test_asgn1; then
    echo "[OK] Userspace ioctl test passed"
else
    echo "[ERROR] Userspace ioctl test failed"
    rmmod asgn1_driver 2>/dev/null
    exit 1
fi

echo
echo "[4] Checking kernel ioctl logs..."

if dmesg | grep -q "ioctl SET_MODE"; then
    echo "[OK] SET_MODE log found"
else
    echo "[ERROR] SET_MODE log not found"
fi

if dmesg | grep -q "ioctl GET_STATS"; then
    echo "[OK] GET_STATS log found"
else
    echo "[ERROR] GET_STATS log not found"
fi

if dmesg | grep -q "ioctl GET_VERSION"; then
    echo "[OK] GET_VERSION log found"
else
    echo "[ERROR] GET_VERSION log not found"
fi

if dmesg | grep -q "ioctl RESET_BUFFER"; then
    echo "[OK] RESET_BUFFER log found"
else
    echo "[ERROR] RESET_BUFFER log not found"
fi

echo
echo "[5] Unloading driver..."

if rmmod asgn1_driver; then
    echo "[OK] Driver unloaded"
else
    echo "[ERROR] Failed to unload driver"
    exit 1
fi

echo
echo "========================================"
echo " ASGN1 TEST COMPLETE"
echo "========================================"

