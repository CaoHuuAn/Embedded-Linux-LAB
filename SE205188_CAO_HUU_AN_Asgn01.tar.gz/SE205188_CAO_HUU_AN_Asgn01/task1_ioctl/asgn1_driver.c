#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/mutex.h>
#include <linux/string.h>
#include <linux/ioctl.h>

#include "asgn1_ioctl.h"

#define DEVICE_NAME "asgn1"
#define ASGN1_MAJOR 241
#define BUFFER_SIZE 1024
#define VERSION_SIZE 64

/*
 * Internal driver state.
 */
static char asgn1_buffer[BUFFER_SIZE];
static int buffer_len;

static int open_count;
static int write_count;
static int read_count;
static int last_write_size;

/*
 * Mode:
 *   0 = Kernel mode
 *   1 = Echo mode
 *
 * Default: Echo mode.
 */
static int mode = 1;

/*
 * Mutex protecting buffer and driver counters.
 */
static DEFINE_MUTEX(asgn1_mutex);

/*
 * Driver version string.
 */
static const char asgn1_version[] =
    "asgn1_driver v1.0 - Embedded Linux";

/*
 * Open the device.
 */
static int asgn1_open(struct inode *inode, struct file *file)
{
    mutex_lock(&asgn1_mutex);

    open_count++;

    pr_info("asgn1_driver: device opened, open_count=%d\n",
            open_count);

    mutex_unlock(&asgn1_mutex);

    return 0;
}

/*
 * Read data from the device.
 */
static ssize_t asgn1_read(struct file *file,
                          char __user *buf,
                          size_t count,
                          loff_t *ppos)
{
    ssize_t ret;

    mutex_lock(&asgn1_mutex);

    if (*ppos >= buffer_len) {
        mutex_unlock(&asgn1_mutex);
        return 0;
    }

    if (count > buffer_len - *ppos)
        count = buffer_len - *ppos;

    if (copy_to_user(buf,
                     asgn1_buffer + *ppos,
                     count)) {
        mutex_unlock(&asgn1_mutex);
        return -EFAULT;
    }

    *ppos += count;
    read_count++;

    ret = count;

    mutex_unlock(&asgn1_mutex);

    return ret;
}

/*
 * Write data to the device.
 *
 * Mode 0:
 *     "[KERNEL]" is automatically prepended.
 *
 * Mode 1:
 *     Data is stored unchanged.
 */
static ssize_t asgn1_write(struct file *file,
                            const char __user *buf,
                            size_t count,
                            loff_t *ppos)
{
    size_t prefix_len = 0;
    size_t data_len;

    if (count == 0)
        return 0;

    mutex_lock(&asgn1_mutex);

    if (mode == 0)
        prefix_len = strlen("[KERNEL]");

    if (count + prefix_len > BUFFER_SIZE) {
        mutex_unlock(&asgn1_mutex);
        return -ENOSPC;
    }

    if (mode == 0) {
        memcpy(asgn1_buffer, "[KERNEL]", prefix_len);

        if (copy_from_user(asgn1_buffer + prefix_len,
                           buf,
                           count)) {
            mutex_unlock(&asgn1_mutex);
            return -EFAULT;
        }

        data_len = prefix_len + count;
    } else {
        if (copy_from_user(asgn1_buffer,
                           buf,
                           count)) {
            mutex_unlock(&asgn1_mutex);
            return -EFAULT;
        }

        data_len = count;
    }

    buffer_len = data_len;
    last_write_size = count;
    write_count++;

    /*
     * Make the next read start from the beginning.
     */
    *ppos = 0;

    pr_info("asgn1_driver: write, mode=%d, size=%zu\n",
            mode, count);

    mutex_unlock(&asgn1_mutex);

    return count;
}

/*
 * Handle ioctl commands.
 */
static long asgn1_ioctl(struct file *file,
                        unsigned int cmd,
                        unsigned long arg)
{
    struct asgn1_stats stats;
    int new_mode;

    mutex_lock(&asgn1_mutex);

    switch (cmd) {

    case ASGN1_RESET_BUFFER:
        memset(asgn1_buffer, 0, sizeof(asgn1_buffer));

        buffer_len = 0;
        write_count = 0;
        read_count = 0;
        last_write_size = 0;

        pr_info("asgn1_driver: ioctl RESET_BUFFER\n");

        mutex_unlock(&asgn1_mutex);
        return 0;

    case ASGN1_GET_STATS:
        stats.open_count = open_count;
        stats.write_count = write_count;
        stats.read_count = read_count;
        stats.buffer_len = buffer_len;
        stats.last_write_size = last_write_size;

        pr_info("asgn1_driver: ioctl GET_STATS\n");

        mutex_unlock(&asgn1_mutex);

        if (copy_to_user((void __user *)arg,
                         &stats,
                         sizeof(stats)))
            return -EFAULT;

        return 0;

    case ASGN1_SET_MODE:
        mutex_unlock(&asgn1_mutex);

        if (copy_from_user(&new_mode,
                           (void __user *)arg,
                           sizeof(new_mode)))
            return -EFAULT;

        if (new_mode != 0 && new_mode != 1)
            return -EINVAL;

        mutex_lock(&asgn1_mutex);

        mode = new_mode;

        pr_info("asgn1_driver: ioctl SET_MODE mode=%d\n",
                mode);

        mutex_unlock(&asgn1_mutex);

        return 0;

    case ASGN1_GET_VERSION:
        pr_info("asgn1_driver: ioctl GET_VERSION\n");

        mutex_unlock(&asgn1_mutex);

        if (copy_to_user((void __user *)arg,
                         asgn1_version,
                         min_t(size_t,
                               strlen(asgn1_version) + 1,
                               VERSION_SIZE)))
            return -EFAULT;

        return 0;

    default:
        pr_info("asgn1_driver: ioctl invalid command=0x%x\n",
                cmd);

        mutex_unlock(&asgn1_mutex);
        return -ENOTTY;
    }
}

/*
 * File operations table.
 */
static const struct file_operations asgn1_fops = {
    .owner = THIS_MODULE,
    .open = asgn1_open,
    .read = asgn1_read,
    .write = asgn1_write,
    .unlocked_ioctl = asgn1_ioctl,
};

/*
 * Initialize the driver.
 */
static int __init asgn1_init(void)
{
    int ret;

    ret = register_chrdev(ASGN1_MAJOR,
                          DEVICE_NAME,
                          &asgn1_fops);

    if (ret < 0) {
        pr_err("asgn1_driver: register_chrdev failed: %d\n",
               ret);
        return ret;
    }

    memset(asgn1_buffer, 0, sizeof(asgn1_buffer));

    buffer_len = 0;
    open_count = 0;
    write_count = 0;
    read_count = 0;
    last_write_size = 0;
    mode = 1;

    pr_info("asgn1_driver: loaded, major=%d, mode=%d\n",
            ASGN1_MAJOR, mode);

    return 0;
}

/*
 * Cleanup the driver.
 */
static void __exit asgn1_exit(void)
{
    unregister_chrdev(ASGN1_MAJOR, DEVICE_NAME);

    pr_info("asgn1_driver: unloaded\n");
}

module_init(asgn1_init);
module_exit(asgn1_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("CAO HỮU AN - SE205188");
MODULE_DESCRIPTION("Assignment 01 ioctl character device driver");
MODULE_VERSION("1.0");
