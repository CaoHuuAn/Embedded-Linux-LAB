#ifndef ASGN1_IOCTL_H
#define ASGN1_IOCTL_H

#include <linux/ioctl.h>

/*
 * Magic number for Assignment 01 driver.
 */
#define ASGN1_IOC_MAGIC 'A'

/*
 * Statistics returned by ASGN1_GET_STATS.
 */
struct asgn1_stats {
    int open_count;
    int write_count;
    int read_count;
    int buffer_len;
    int last_write_size;
};

/*
 * Reset internal buffer and read/write counters.
 * No argument.
 */
#define ASGN1_RESET_BUFFER \
    _IO(ASGN1_IOC_MAGIC, 1)

/*
 * Get driver statistics.
 */
#define ASGN1_GET_STATS \
    _IOR(ASGN1_IOC_MAGIC, 2, struct asgn1_stats)

/*
 * Set driver operating mode.
 *
 * Mode 0: Kernel mode
 * Mode 1: Echo mode
 */
#define ASGN1_SET_MODE \
    _IOW(ASGN1_IOC_MAGIC, 3, int)

/*
 * Get driver version string.
 */
#define ASGN1_GET_VERSION \
    _IOR(ASGN1_IOC_MAGIC, 4, char[64])

#endif /* ASGN1_IOCTL_H */
