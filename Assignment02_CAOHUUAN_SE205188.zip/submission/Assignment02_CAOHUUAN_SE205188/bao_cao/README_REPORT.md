# ASSIGNMENT 02 — SENSOR MONITORING SYSTEM

**Student:** CAO HUU AN  
**MSSV:** SE205188  
**Course:** Embedded Linux  
**Platform:** ARMv7 Cortex-A9 / QEMU vexpress-a9  
**Kernel:** Linux 6.6.21  

---

## 1. Project Overview

This project implements a Sensor Monitoring System on Embedded Linux.

The system consists of:

- A Linux kernel module providing the `/dev/sms_sensor` character device.
- A `/proc/sms_stats` interface for driver statistics.
- A multi-threaded user-space application.
- Sensor, Processor, Alert, and Logger threads.
- POSIX message queues for alert communication.
- A circular buffer for sensor data.
- Real-time scheduling and jitter measurement for the sensor thread.
- Valgrind, strace, perf, and GDB based debugging/profiling.

The target platform is ARMv7 Cortex-A9 running Linux 6.6.21 on QEMU `vexpress-a9`.

---

## 2. System Architecture

The system follows the following processing pipeline:

```text
                    +----------------------+
                    |   SMS Sensor Driver  |
                    |  /dev/sms_sensor     |
                    |  /proc/sms_stats     |
                    +----------+-----------+
                               |
                               | sensor data
                               v
                    +----------------------+
                    |    Sensor Thread     |
                    | SCHED_FIFO / OTHER   |
                    | clock_nanosleep()    |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    |   Circular Buffer    |
                    | shared_buffer        |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    |  Processor Thread    |
                    | threshold detection  |
                    +----------+-----------+
                               |
                 +-------------+-------------+
                 |                           |
                 v                           v
       +-------------------+       +-------------------+
       |   Alert Thread    |       |   Logger Thread   |
       | POSIX MQ          |       | /tmp/sms.log      |
       +-------------------+       +-------------------+
---

## 3. Kernel Driver

The kernel module is implemented in:

driver/sms_sensor_driver.c
driver/sms_sensor.h

The driver provides:

- Character device /dev/sms_sensor
- /proc/sms_stats
- Random temperature generation in the range 15–45 °C
- Random humidity generation in the range 30–90 %
- Read counter
- Driver uptime measurement
- Configurable sampling interval through ioctl

The ioctl interface is:

SMS_SET_INTERVAL

The default driver interval is 100 ms.

The final kernel module was built for:

Linux 6.6.21
ARMv7
vexpress-a9

Final module verification:

ELF 32-bit LSB relocatable, ARM, EABI5
with debug_info, not stripped

vermagic:
6.6.21 SMP mod_unload ARMv7 p2v8

The final module size is approximately 148 KB.

The module was copied into:

rootfs/initramfs_asgn2/lib/modules/6.6.21/sms_sensor_driver.ko

---

## 4. User-space Application

The user-space application is divided into multiple source files:

sms_app.c
sensor_thread.c
sensor_thread.h
processor_thread.c
processor_thread.h
alert_thread.c
alert_thread.h
logger_thread.c
logger_thread.h
circular_buffer.c
circular_buffer.h

The application creates four worker threads:

1. Sensor Thread
2. Processor Thread
3. Alert Thread
4. Logger Thread

The application also contains signal handling for clean shutdown using SIGINT/SIGTERM.

The final ARM application is:

app/sms_app

It is:

ELF 32-bit ARM
EABI5
statically linked
not stripped

The final application size is approximately 635 KB.

A host x86-64 version is also provided:

app/sms_app_x86

This version was used for Valgrind, strace, perf, and GDB analysis.

---

## 5. Task 1 — Functional Test

The application was tested for approximately 60 seconds using:

-i 500
-t 40
-h 80
-d 60
-v

The final T1 log is:

logs/t1_60s.txt

Important results:

Shutdown complete
Produced       : 120
Consumed       : 120
Buffer current : 0
Overflow       : 0

The application completed the test without crashing.

The four worker threads were created successfully and the application performed a clean shutdown.

The equality between Produced and Consumed demonstrates that all generated sensor samples were processed during the test.

The circular buffer ended with zero pending samples and zero overflow.

---

## 6. Task 2 — Memory and Valgrind Analysis

### 6.1 Valgrind

The host version sms_app_x86 was tested using Valgrind with:

--leak-check=full
--show-leak-kinds=all
--track-origins=yes

The complete result is stored in:

logs/valgrind_sms.txt

Final Valgrind result:

HEAP SUMMARY:
    in use at exit: 0 bytes in 0 blocks

All heap blocks were freed -- no leaks are possible

ERROR SUMMARY: 0 errors from 0 contexts

The application allocated and released all dynamically allocated memory correctly.

Therefore, Valgrind reported:

0 bytes definitely lost
0 errors

---

### 6.2 QEMU Memory Footprint

During the ARM/QEMU test, /proc/PID/status was inspected at approximately:

- 5 seconds
- 30 seconds
- 55 seconds

The measured values were stable:

Time       VmSize       VmRSS
5 s        35584 kB     33664 kB
30 s       35584 kB     33664 kB
55 s       35584 kB     33664 kB

The stable memory footprint indicates that the application did not continuously grow its address space or resident memory during the test.

The process contained five threads:

Threads: 5

---

### 6.3 Memory Map

The process memory map contained the following important regions:

/usr/bin/sms_app
[heap]
thread stacks
guard regions
[sigpage]
[vvar]
[vdso]
[vectors]

At least five regions were identified:

1. Executable text — contains application machine code.
2. Read-only data — contains read-only program data.
3. Writable data — contains global/static writable data.
4. Heap — dynamic memory allocation.
5. Thread stacks — per-thread execution stacks.
6. Guard regions — protect against stack overflow.
7. VDSO/VVAR — kernel-provided user-space interfaces and timing information.
8. ARM vectors — architecture-specific exception/vector mapping.

---

## 7. Task 3 — Debugging and Profiling

### 7.1 strace

System calls were traced using:

strace -f -tt -T

The complete trace is stored in:

logs/strace_sms.txt

The trace demonstrated the use of:

- thread creation
- futex synchronization
- POSIX message queues
- file operations
- timing operations
- process/thread shutdown

The strace log size is approximately 242 KB.

---

### 7.2 perf

Performance measurement was performed using:

perf stat

The complete result is stored in:

logs/perf_sms.txt

The measured elapsed time was:

40.539264276 seconds

User CPU time:

0.007338 seconds

System CPU time:

0.026419 seconds

The CPU-cycles hardware counter was reported as unsupported by the test environment:

<not supported> cpu-cycles:u

Therefore, no CPU-cycle conclusion was made from this counter.

---

### 7.3 GDB

GDB was used to verify the application threads.

Breakpoints were placed at:

main
sensor_thread_func
processor_thread_func
alert_thread_func
logger_thread_func

All five breakpoints were hit.

GDB also confirmed five application threads:

Main thread
Logger thread
Alert thread
Processor thread
Sensor thread

The complete debugging summary is stored in:

logs/gdb_sms.txt

This confirms that all four required worker threads reached their intended entry functions.

---

## 8. Task 4 — Real-time Scheduling and Jitter

The Sensor Thread implements:

CLOCK_MONOTONIC
clock_nanosleep()
TIMER_ABSTIME

The implementation collects more than 1000 jitter samples and calculates:

- Minimum jitter
- Average jitter
- Maximum jitter
- P99 jitter
- Text histogram

The test results are stored in:

logs/jitter_report.txt

### 8.1 ARM/QEMU SCHED_OTHER

Jitter samples : 1497
Min            : 137 us
Average        : 489.34 us
Max            : 1636 us
P99            : 1063 us
mlockall       : SUCCESS

### 8.2 ARM/QEMU SCHED_FIFO Priority 50

Requested policy : SCHED_FIFO priority 50
Active policy    : SCHED_FIFO

Jitter samples : 1498
Min            : 149 us
Average        : 505.40 us
Max            : 1737 us
P99            : 1196 us
mlockall       : SUCCESS

The ARM/QEMU test successfully activated:

SCHED_FIFO priority 50

and:

mlockall(MCL_CURRENT | MCL_FUTURE)

successfully returned on the QEMU target.

Interestingly, SCHED_FIFO did not produce lower measured jitter in this particular QEMU environment.

| Metric | SCHED_OTHER | SCHED_FIFO |
|---|---:|---:|
| Samples | 1497 | 1498 |
| Min | 137 us | 149 us |
| Average | 489.34 us | 505.40 us |
| Max | 1636 us | 1737 us |
| P99 | 1063 us | 1196 us |

This result does not indicate an implementation failure. QEMU virtualization and host scheduling can significantly affect timing measurements.

The important result is that the Sensor Thread successfully entered SCHED_FIFO priority 50 on the ARM/QEMU target and used absolute-deadline sleeping.

---

## 9. Synchronization and Concurrency

The application consists of four concurrent worker threads.

Shared data structures are protected using synchronization mechanisms appropriate to their access patterns.

The circular buffer coordinates sensor production and processor consumption.

The alert subsystem uses POSIX message queues.

The logger thread serializes logging operations to the log file.

Clean shutdown is implemented using SIGINT/SIGTERM handling followed by pthread_join() for all worker threads.

The T1 test demonstrated:

Produced : 120
Consumed : 120
Overflow : 0

which indicates correct producer-consumer synchronization during the 60-second test.

---

## 10. Memory Footprint Analysis

The ARM/QEMU process remained stable throughout the memory observation period.

VmSize = 35584 kB
VmRSS  = 33664 kB

These values were unchanged at approximately 5, 30, and 55 seconds.

The stable memory footprint, together with the Valgrind result of zero bytes in use at exit, indicates that no progressive memory growth was observed during testing.

---

## 11. Results and Discussion

The final system successfully integrated the Linux kernel driver with the ARM user-space application.

The final QEMU smoke test produced:

Produced       : 18
Consumed       : 18
Buffer current : 0
Overflow       : 0
TEMP_HIGH      : 3
HUMID_HIGH     : 2
TEMP_SPIKE     : 12

The final driver statistics were:

read_count: 18
last_temperature: 31.0 C
last_humidity: 48.1 %
driver_uptime: 103 s

The read_count exactly matched the number of samples produced and consumed by the application.

This demonstrates successful end-to-end communication:

Kernel Driver
     ↓
/dev/sms_sensor
     ↓
Sensor Thread
     ↓
Circular Buffer
     ↓
Processor Thread
     ↓
Alert / Logger

---

## 12. Reflection

This assignment provided practical experience with Linux kernel modules, character devices, /proc, ioctl interfaces, multi-threaded programming, synchronization, POSIX message queues, memory analysis, system-call tracing, debugging, performance profiling, and real-time scheduling.

One important observation was that real-time behavior depends not only on application code but also on system permissions and the execution environment.

On the host system, SCHED_FIFO priority 50 could not be enabled because:

ulimit -r = 0

However, the same real-time scheduling configuration was successfully activated on the ARM/QEMU target.

The jitter results also demonstrated that SCHED_FIFO does not automatically guarantee lower measured jitter in a virtualized environment. QEMU and the host scheduler introduce additional timing variability.

The assignment therefore provided both implementation experience and practical understanding of the limitations of real-time measurements.

---

## 13. Demo Procedure

The final demonstration can be performed using the following sequence:

### Step 1 — Boot QEMU

Boot using:

Linux 6.6.21
vexpress-a9
initramfs_asgn2.cpio.gz

### Step 2 — Verify driver

ls -l /dev/sms_sensor
cat /proc/sms_stats

### Step 3 — Run application

/usr/bin/sms_app -i 500 -t 40 -h 80 -d 60 -v

### Step 4 — Show clean shutdown

Show:

Shutdown complete
Produced
Consumed
Buffer current
Overflow

### Step 5 — Show driver statistics

cat /proc/sms_stats

### Step 6 — Show real-time analysis

Show:

logs/jitter_report.txt

and explain the SCHED_OTHER versus SCHED_FIFO results.

---

## 14. Conclusion

The Assignment 02 Sensor Monitoring System was successfully implemented and tested on ARMv7 Cortex-A9 using QEMU.

The final system provides:

- Functional kernel sensor driver
- /dev/sms_sensor
- /proc/sms_stats
- ioctl interval configuration
- Four-thread user-space architecture
- Circular buffer synchronization
- POSIX message queue based alert handling
- Logging
- Clean signal-based shutdown
- Valgrind memory verification
- strace system-call tracing
- perf profiling
- GDB thread verification
- Real-time scheduling
- Jitter measurement with more than 1000 samples

The final QEMU smoke test completed successfully with:

Produced : 18
Consumed : 18
Overflow : 0

Therefore, the final ARM application and initramfs image were verified before submission.

---

## 15. Submission Files

Important project files include:

driver/
app/
rootfs/initramfs_asgn2/
output/initramfs_asgn2.cpio.gz
logs/
bao_cao/
demo/

Important logs:

logs/t1_60s.txt
logs/valgrind_sms.txt
logs/strace_sms.txt
logs/perf_sms.txt
logs/gdb_sms.txt
logs/jitter_report.txt
logs/jitter_report_other.txt
logs/jitter_report_fifo.txt
logs/jitter_report_other_arm.txt
logs/jitter_report_fifo_arm.txt
logs/proc_sms_stats_before.txt
logs/proc_sms_stats_after.txt

Final binaries:

app/sms_app
app/sms_app_x86
driver/sms_sensor_driver.ko
output/initramfs_asgn2.cpio.gz

