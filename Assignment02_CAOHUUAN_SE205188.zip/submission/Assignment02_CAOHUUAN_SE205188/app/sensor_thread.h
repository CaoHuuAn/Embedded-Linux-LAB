#ifndef SENSOR_THREAD_H
#define SENSOR_THREAD_H

#include <pthread.h>

#include "circular_buffer.h"

typedef struct {
    CircularBuffer *buffer;

    int interval_ms;
    int verbose;

    volatile int *running;
} SensorThreadConfig;

void *sensor_thread_func(void *arg);

#endif
