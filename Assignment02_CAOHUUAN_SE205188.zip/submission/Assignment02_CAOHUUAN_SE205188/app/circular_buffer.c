#include "circular_buffer.h"

#include <errno.h>
#include <stdlib.h>
#include <string.h>

int circular_buffer_init(CircularBuffer *cb, size_t capacity)
{
    if (cb == NULL || capacity == 0)
        return EINVAL;

    memset(cb, 0, sizeof(*cb));

    cb->data = calloc(capacity, sizeof(SensorData));

    if (cb->data == NULL)
        return ENOMEM;

    cb->capacity = capacity;

    if (pthread_mutex_init(&cb->mutex, NULL) != 0) {
        free(cb->data);
        cb->data = NULL;
        return EINVAL;
    }

    if (pthread_cond_init(&cb->not_empty, NULL) != 0) {
        pthread_mutex_destroy(&cb->mutex);
        free(cb->data);
        cb->data = NULL;
        return EINVAL;
    }

    if (pthread_cond_init(&cb->not_full, NULL) != 0) {
        pthread_cond_destroy(&cb->not_empty);
        pthread_mutex_destroy(&cb->mutex);
        free(cb->data);
        cb->data = NULL;
        return EINVAL;
    }

    cb->stopped = 0;

    return 0;
}

void circular_buffer_destroy(CircularBuffer *cb)
{
    if (cb == NULL)
        return;

    pthread_mutex_lock(&cb->mutex);

    cb->stopped = 1;

    pthread_cond_broadcast(&cb->not_empty);
    pthread_cond_broadcast(&cb->not_full);

    pthread_mutex_unlock(&cb->mutex);

    pthread_cond_destroy(&cb->not_empty);
    pthread_cond_destroy(&cb->not_full);
    pthread_mutex_destroy(&cb->mutex);

    free(cb->data);
    cb->data = NULL;

    cb->capacity = 0;
    cb->head = 0;
    cb->tail = 0;
    cb->size = 0;
}

int circular_buffer_push(CircularBuffer *cb, const SensorData *item)
{
    if (cb == NULL || item == NULL)
        return EINVAL;

    pthread_mutex_lock(&cb->mutex);

    if (cb->stopped) {
        pthread_mutex_unlock(&cb->mutex);
        return ECANCELED;
    }

    if (cb->size == cb->capacity) {
        cb->overflow_count++;

        pthread_mutex_unlock(&cb->mutex);
        return ENOSPC;
    }

    cb->data[cb->head] = *item;

    cb->head = (cb->head + 1) % cb->capacity;
    cb->size++;
    cb->total_produced++;

    pthread_cond_signal(&cb->not_empty);

    pthread_mutex_unlock(&cb->mutex);

    return 0;
}

int circular_buffer_pop(CircularBuffer *cb, SensorData *item)
{
    if (cb == NULL || item == NULL)
        return EINVAL;

    pthread_mutex_lock(&cb->mutex);

    while (cb->size == 0 && !cb->stopped) {
        int ret = pthread_cond_wait(&cb->not_empty, &cb->mutex);

        if (ret != 0) {
            pthread_mutex_unlock(&cb->mutex);
            return ret;
        }
    }

    if (cb->size == 0 && cb->stopped) {
        pthread_mutex_unlock(&cb->mutex);
        return ECANCELED;
    }

    *item = cb->data[cb->tail];

    cb->tail = (cb->tail + 1) % cb->capacity;
    cb->size--;
    cb->total_consumed++;

    pthread_cond_signal(&cb->not_full);

    pthread_mutex_unlock(&cb->mutex);

    return 0;
}

void circular_buffer_stop(CircularBuffer *cb)
{
    if (cb == NULL)
        return;

    pthread_mutex_lock(&cb->mutex);

    cb->stopped = 1;

    pthread_cond_broadcast(&cb->not_empty);
    pthread_cond_broadcast(&cb->not_full);

    pthread_mutex_unlock(&cb->mutex);
}

size_t circular_buffer_current_size(CircularBuffer *cb)
{
    size_t result;

    if (cb == NULL)
        return 0;

    pthread_mutex_lock(&cb->mutex);
    result = cb->size;
    pthread_mutex_unlock(&cb->mutex);

    return result;
}

unsigned long circular_buffer_total_produced(CircularBuffer *cb)
{
    unsigned long result;

    if (cb == NULL)
        return 0;

    pthread_mutex_lock(&cb->mutex);
    result = cb->total_produced;
    pthread_mutex_unlock(&cb->mutex);

    return result;
}

unsigned long circular_buffer_total_consumed(CircularBuffer *cb)
{
    unsigned long result;

    if (cb == NULL)
        return 0;

    pthread_mutex_lock(&cb->mutex);
    result = cb->total_consumed;
    pthread_mutex_unlock(&cb->mutex);

    return result;
}

unsigned long circular_buffer_overflow_count(CircularBuffer *cb)
{
    unsigned long result;

    if (cb == NULL)
        return 0;

    pthread_mutex_lock(&cb->mutex);
    result = cb->overflow_count;
    pthread_mutex_unlock(&cb->mutex);

    return result;
}
