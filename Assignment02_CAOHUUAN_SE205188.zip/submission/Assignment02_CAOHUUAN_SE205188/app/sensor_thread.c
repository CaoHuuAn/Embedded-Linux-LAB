#include "sensor_thread.h"

#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>

#include "../driver/sms_sensor.h"

#define JITTER_MAX_SAMPLES 4096U
#define FIFO_PRIORITY 50

typedef struct {
    long long *samples_us;
    size_t count;
    size_t capacity;
    long long min_us;
    long long max_us;
    double avg_us;
    long long p99_us;
    int policy_requested_fifo;
    int policy_active;
    int fifo_errno;
    int mlock_errno;
} JitterStats;


static long long monotonic_us(void)
{
    struct timespec ts;

    if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0)
        return 0LL;

    return (long long)ts.tv_sec * 1000000LL +
           (long long)ts.tv_nsec / 1000LL;
}

static int sleep_until(const struct timespec *deadline)
{
    int rc;

    do {
        rc = clock_nanosleep(CLOCK_MONOTONIC,
                             TIMER_ABSTIME,
                             deadline,
                             NULL);
    } while (rc == EINTR);

    return rc;
}

static void add_ms_to_timespec(struct timespec *ts, int interval_ms)
{
    ts->tv_nsec += (long)interval_ms * 1000000L;

    while (ts->tv_nsec >= 1000000000L) {
        ts->tv_sec++;
        ts->tv_nsec -= 1000000000L;
    }
}

static int compare_long_long(const void *a, const void *b)
{
    const long long va = *(const long long *)a;
    const long long vb = *(const long long *)b;

    if (va < vb)
        return -1;

    if (va > vb)
        return 1;

    return 0;
}

static void jitter_init(JitterStats *stats)
{
    memset(stats, 0, sizeof(*stats));

    stats->samples_us = calloc(JITTER_MAX_SAMPLES,
                               sizeof(*stats->samples_us));

    if (stats->samples_us == NULL)
        return;

    stats->capacity = JITTER_MAX_SAMPLES;
    stats->min_us = -1;
}

static void jitter_record(JitterStats *stats, long long jitter_us)
{
    if (stats == NULL || stats->samples_us == NULL)
        return;

    if (jitter_us < 0)
        jitter_us = -jitter_us;

    if (stats->count >= stats->capacity)
        return;

    stats->samples_us[stats->count++] = jitter_us;

    if (stats->min_us < 0 || jitter_us < stats->min_us)
        stats->min_us = jitter_us;

    if (jitter_us > stats->max_us)
        stats->max_us = jitter_us;
}

static void jitter_finish(JitterStats *stats)
{
    size_t i;
    long double total = 0.0L;
    size_t p99_index;

    if (stats == NULL || stats->count == 0)
        return;

    for (i = 0; i < stats->count; i++)
        total += stats->samples_us[i];

    stats->avg_us = (double)(total / (long double)stats->count);

    qsort(stats->samples_us,
          stats->count,
          sizeof(stats->samples_us[0]),
          compare_long_long);

    p99_index = (stats->count * 99U + 99U) / 100U;

    if (p99_index > 0)
        p99_index--;

    stats->p99_us = stats->samples_us[p99_index];
}

static void jitter_write_histogram(FILE *fp, const JitterStats *stats)
{
    static const long long limits[] = {
        100,
        500,
        1000,
        5000,
        10000,
        50000,
        100000
    };

    size_t counts[sizeof(limits) / sizeof(limits[0]) + 1] = {0};
    size_t i;
    size_t bucket;

    if (fp == NULL || stats == NULL)
        return;

    for (i = 0; i < stats->count; i++) {
        long long value = stats->samples_us[i];

        for (bucket = 0;
             bucket < sizeof(limits) / sizeof(limits[0]);
             bucket++) {
            if (value <= limits[bucket])
                break;
        }

        counts[bucket]++;
    }

    fprintf(fp, "\nJitter histogram (absolute jitter, us):\n");

    fprintf(fp, "  <= 100 us    : %zu\n", counts[0]);
    fprintf(fp, "  101-500 us   : %zu\n", counts[1]);
    fprintf(fp, "  501-1000 us  : %zu\n", counts[2]);
    fprintf(fp, "  1001-5000 us : %zu\n", counts[3]);
    fprintf(fp, "  5001-10000 us: %zu\n", counts[4]);
    fprintf(fp, "  10001-50000 us: %zu\n", counts[5]);
    fprintf(fp, "  50001-100000 us: %zu\n", counts[6]);
    fprintf(fp, "  > 100000 us  : %zu\n", counts[7]);
}

static void jitter_report(const JitterStats *stats)
{
    const char *report_path;
    FILE *fp;

    if (stats == NULL)
        return;

    printf("\n[T4] Scheduling / jitter report\n");

    if (stats->policy_requested_fifo) {
        if (stats->policy_active == SCHED_FIFO) {
            printf("[T4] Requested policy : SCHED_FIFO\n");
            printf("[T4] Active policy    : SCHED_FIFO\n");
            printf("[T4] Priority         : %d\n", FIFO_PRIORITY);
        } else {
            printf("[T4] Requested policy : SCHED_FIFO priority %d\n",
                   FIFO_PRIORITY);
            printf("[T4] Active policy    : SCHED_OTHER\n");
            printf("[T4] SCHED_FIFO failed: %s\n",
                   strerror(stats->fifo_errno));
        }
    } else {
        printf("[T4] Requested policy : SCHED_OTHER\n");
        printf("[T4] Active policy    : SCHED_OTHER\n");
    }

    if (stats->mlock_errno == 0) {
        printf("[T4] mlockall         : SUCCESS\n");
    } else {
        printf("[T4] mlockall         : FAILED (%s)\n",
               strerror(stats->mlock_errno));
    }

    printf("[T4] Jitter samples   : %zu\n", stats->count);

    if (stats->count > 0) {
        printf("[T4] Min jitter       : %lld us\n",
               stats->min_us);
        printf("[T4] Avg jitter       : %.2f us\n",
               stats->avg_us);
        printf("[T4] Max jitter       : %lld us\n",
               stats->max_us);
        printf("[T4] P99 jitter       : %lld us\n",
               stats->p99_us);
    }

    report_path = getenv("SMS_JITTER_REPORT");

    if (report_path == NULL || report_path[0] == '\0')
        return;

    fp = fopen(report_path, "w");

    if (fp == NULL) {
        fprintf(stderr,
                "[T4] Cannot open jitter report '%s': %s\n",
                report_path,
                strerror(errno));
        return;
    }

    fprintf(fp, "Assignment 02 - T4 Jitter Report\n");
    fprintf(fp, "================================\n\n");

    fprintf(fp, "Requested policy : ");

    if (stats->policy_requested_fifo)
        fprintf(fp, "SCHED_FIFO priority %d\n", FIFO_PRIORITY);
    else
        fprintf(fp, "SCHED_OTHER\n");

    fprintf(fp, "Active policy    : ");

    if (stats->policy_active == SCHED_FIFO)
        fprintf(fp, "SCHED_FIFO\n");
    else
        fprintf(fp, "SCHED_OTHER\n");

    if (stats->policy_requested_fifo &&
        stats->policy_active != SCHED_FIFO) {
        fprintf(fp, "FIFO error       : %s\n",
                strerror(stats->fifo_errno));
    }

    if (stats->mlock_errno == 0) {
        fprintf(fp, "mlockall         : SUCCESS\n");
    } else {
        fprintf(fp, "mlockall         : FAILED (%s)\n",
                strerror(stats->mlock_errno));
    }

    fprintf(fp, "\nJitter samples   : %zu\n", stats->count);

    if (stats->count > 0) {
        fprintf(fp, "Min jitter       : %lld us\n",
                stats->min_us);
        fprintf(fp, "Avg jitter       : %.2f us\n",
                stats->avg_us);
        fprintf(fp, "Max jitter       : %lld us\n",
                stats->max_us);
        fprintf(fp, "P99 jitter       : %lld us\n",
                stats->p99_us);
    }

    jitter_write_histogram(fp, stats);

    fclose(fp);

    printf("[T4] Report saved: %s\n", report_path);
}

static void setup_realtime(JitterStats *stats)
{
    const char *policy;
    struct sched_param param;
    int rc;

    stats->policy_requested_fifo = 0;
    stats->policy_active = SCHED_OTHER;
    stats->fifo_errno = 0;
    stats->mlock_errno = 0;

    if (mlockall(MCL_CURRENT | MCL_FUTURE) != 0) {
        stats->mlock_errno = errno;

        fprintf(stderr,
                "[T4] mlockall failed: %s\n",
                strerror(errno));
    } else {
        if (stats->policy_requested_fifo)
            printf("[T4] mlockall succeeded\n");
    }

    policy = getenv("SMS_SCHED_POLICY");

    if (policy == NULL ||
        strcmp(policy, "FIFO") != 0) {
        return;
    }

    stats->policy_requested_fifo = 1;

    memset(&param, 0, sizeof(param));
    param.sched_priority = FIFO_PRIORITY;

    rc = pthread_setschedparam(pthread_self(),
                               SCHED_FIFO,
                               &param);

    if (rc != 0) {
        stats->fifo_errno = rc;

        fprintf(stderr,
                "[T4] pthread_setschedparam(SCHED_FIFO, %d) failed: %s\n",
                FIFO_PRIORITY,
                strerror(rc));

        return;
    }

    stats->policy_active = SCHED_FIFO;

    printf("[T4] SCHED_FIFO priority %d enabled\n",
           FIFO_PRIORITY);
}

#ifdef HOST_BUILD


static unsigned long long monotonic_ms(void)
{
    struct timespec ts;

    if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0)
        return 0ULL;

    return (unsigned long long)ts.tv_sec * 1000ULL +
           (unsigned long long)ts.tv_nsec / 1000000ULL;
}

static void generate_host_sensor_data(SensorData *sample)
{
    static unsigned int seed = 12345U;

    sample->timestamp_ms = monotonic_ms();

    sample->temperature =
        15.0f + ((float)(rand_r(&seed) % 3001U) / 100.0f);

    sample->humidity =
        30.0f + ((float)(rand_r(&seed) % 6001U) / 100.0f);
}

#endif

void *sensor_thread_func(void *arg)
{
    SensorThreadConfig *config = arg;
    JitterStats jitter;
    struct timespec next_deadline;
    int interval_ms;
    int sleep_rc;

    if (config == NULL ||
        config->buffer == NULL ||
        config->running == NULL) {
        return NULL;
    }

    interval_ms = config->interval_ms;

    if (interval_ms <= 0)
        interval_ms = 1;

    jitter_init(&jitter);

    setup_realtime(&jitter);

    if (clock_gettime(CLOCK_MONOTONIC, &next_deadline) != 0) {
        fprintf(stderr,
                "[T4] clock_gettime failed: %s\n",
                strerror(errno));

        free(jitter.samples_us);
        return NULL;
    }

    if (config->verbose) {
#ifdef HOST_BUILD
        printf("[Sensor] Started: host simulation, interval=%d ms\n",
               interval_ms);
#else
        printf("[Sensor] Started: interval=%d ms\n",
               interval_ms);
#endif
    }

#ifdef HOST_BUILD

    while (!*(config->running)) {
        long long scheduled_us;
        long long actual_us;
        SensorData sample;

        add_ms_to_timespec(&next_deadline, interval_ms);

        sleep_rc = sleep_until(&next_deadline);

        if (sleep_rc != 0 && sleep_rc != EINTR) {
            fprintf(stderr,
                    "[T4] clock_nanosleep failed: %s\n",
                    strerror(sleep_rc));
            break;
        }

        actual_us = monotonic_us();

        scheduled_us =
            (long long)next_deadline.tv_sec * 1000000LL +
            (long long)next_deadline.tv_nsec / 1000LL;

        jitter_record(&jitter,
                      actual_us - scheduled_us);

        if (*(config->running))
            break;

        generate_host_sensor_data(&sample);

        if (circular_buffer_push(config->buffer, &sample) != 0) {
            if (config->verbose) {
                fprintf(stderr,
                        "[Sensor] Buffer full, sample dropped\n");
            }
        } else if (config->verbose) {
            printf("[Sensor] %llu %.1f %.1f\n",
                   sample.timestamp_ms,
                   sample.temperature,
                   sample.humidity);
        }
    }

#else

    {
        int fd;
        unsigned long interval;
        char buffer[128];

        fd = open(SMS_DEVICE_PATH, O_RDONLY);

        if (fd < 0) {
            perror("sensor_thread: open");
            free(jitter.samples_us);
            return NULL;
        }

        interval = (unsigned long)interval_ms;

        if (ioctl(fd, SMS_SET_INTERVAL, &interval) < 0) {
            perror("sensor_thread: ioctl SMS_SET_INTERVAL");
            close(fd);
            free(jitter.samples_us);
            return NULL;
        }

        while (!*(config->running)) {
            long long scheduled_us;
            long long actual_us;
            ssize_t n;
            unsigned long long timestamp_ms;
            float temperature;
            float humidity;
            SensorData sample;

            add_ms_to_timespec(&next_deadline, interval_ms);

            sleep_rc = sleep_until(&next_deadline);

            if (sleep_rc != 0 && sleep_rc != EINTR) {
                fprintf(stderr,
                        "[T4] clock_nanosleep failed: %s\n",
                        strerror(sleep_rc));
                break;
            }

            actual_us = monotonic_us();

            scheduled_us =
                (long long)next_deadline.tv_sec * 1000000LL +
                (long long)next_deadline.tv_nsec / 1000LL;

            jitter_record(&jitter,
                          actual_us - scheduled_us);

            if (*(config->running))
                break;

            n = read(fd, buffer, sizeof(buffer) - 1);

            if (n > 0) {
                buffer[n] = '\0';

                if (sscanf(buffer, "%llu,%f,%f",
                           &timestamp_ms,
                           &temperature,
                           &humidity) == 3) {

                    sample.timestamp_ms = timestamp_ms;
                    sample.temperature = temperature;
                    sample.humidity = humidity;

                    if (circular_buffer_push(config->buffer,
                                             &sample) != 0) {
                        if (config->verbose) {
                            fprintf(stderr,
                                    "[Sensor] Buffer full, sample dropped\n");
                        }
                    } else if (config->verbose) {
                        printf("[Sensor] %llu %.1f %.1f\n",
                               timestamp_ms,
                               temperature,
                               humidity);
                    }
                } else if (config->verbose) {
                    fprintf(stderr,
                            "[Sensor] Invalid sensor data: %s",
                            buffer);
                }
            } else if (n < 0) {
                if (errno == EINTR)
                    continue;

                if (errno == EAGAIN) {
                    continue;
                }

                perror("sensor_thread: read");
                break;
            } else {
                if (config->verbose)
                    fprintf(stderr,
                            "[Sensor] Driver returned EOF\n");
                break;
            }
        }

        close(fd);
    }

#endif

    jitter_finish(&jitter);

    if (config->verbose)
        printf("[Sensor] Stopped\n");

    jitter_report(&jitter);

    free(jitter.samples_us);

    return NULL;
}
