#include <errno.h>
#include <getopt.h>
#include <mqueue.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "alert_thread.h"
#include "circular_buffer.h"
#include "logger_thread.h"
#include "processor_thread.h"
#include "sensor_thread.h"

#define BUFFER_CAPACITY 64
#define ALARM_QUEUE_NAME "/alarm_queue"
#define LOGGER_QUEUE_NAME "/logger_queue"

static volatile sig_atomic_t stop_requested = 0;

static void signal_handler(int signo)
{
    if (signo == SIGINT || signo == SIGTERM)
        stop_requested = 1;
}

static void print_usage(const char *program)
{
    printf("Usage: %s [options]\n", program);
    printf("\n");
    printf("Options:\n");
    printf("  -i <ms>   Sensor interval (default: 500)\n");
    printf("  -t <C>    Temperature threshold (default: 40)\n");
    printf("  -h <%%>    Humidity threshold (default: 80)\n");
    printf("  -d <sec>  Duration (default: 60)\n");
    printf("  -v        Verbose output\n");
    printf("  -?        Show this help\n");
}

int main(int argc, char *argv[])
{
    int interval_ms = 500;
    int temperature_threshold = 40;
    int humidity_threshold = 80;
    int duration_sec = 60;
    int verbose = 0;

    int opt;

    CircularBuffer buffer;

    pthread_t sensor_thread;
    pthread_t processor_thread;
    pthread_t alert_thread;
    pthread_t logger_thread;

    SensorThreadConfig sensor_config;
    ProcessorThreadConfig processor_config;
    AlertThreadConfig alert_config;
    LoggerThreadConfig logger_config;

    mqd_t alarm_queue = (mqd_t)-1;
    mqd_t logger_queue = (mqd_t)-1;

    struct mq_attr alarm_attr;
    struct mq_attr logger_attr;

    struct sigaction sa;

    memset(&buffer, 0, sizeof(buffer));
    memset(&sensor_config, 0, sizeof(sensor_config));
    memset(&processor_config, 0, sizeof(processor_config));
    memset(&alert_config, 0, sizeof(alert_config));
    memset(&logger_config, 0, sizeof(logger_config));
    memset(&alarm_attr, 0, sizeof(alarm_attr));
    memset(&logger_attr, 0, sizeof(logger_attr));
    memset(&sa, 0, sizeof(sa));

    while ((opt = getopt(argc, argv, "i:t:h:d:v?")) != -1) {
        switch (opt) {
        case 'i':
            interval_ms = atoi(optarg);
            break;

        case 't':
            temperature_threshold = atoi(optarg);
            break;

        case 'h':
            humidity_threshold = atoi(optarg);
            break;

        case 'd':
            duration_sec = atoi(optarg);
            break;

        case 'v':
            verbose = 1;
            break;

        case '?':
            print_usage(argv[0]);
            return 0;

        default:
            print_usage(argv[0]);
            return 1;
        }
    }

    if (interval_ms <= 0 || duration_sec <= 0) {
        fprintf(stderr, "Invalid interval or duration\n");
        return 1;
    }

    sa.sa_handler = signal_handler;
    sigemptyset(&sa.sa_mask);

    if (sigaction(SIGINT, &sa, NULL) < 0 ||
        sigaction(SIGTERM, &sa, NULL) < 0) {
        perror("sigaction");
        return 1;
    }

    alarm_attr.mq_flags = 0;
    alarm_attr.mq_maxmsg = 16;
    alarm_attr.mq_msgsize = 256;
    alarm_attr.mq_curmsgs = 0;

    logger_attr.mq_flags = 0;
    logger_attr.mq_maxmsg = 32;
    logger_attr.mq_msgsize = 512;
    logger_attr.mq_curmsgs = 0;

    mq_unlink(ALARM_QUEUE_NAME);
    mq_unlink(LOGGER_QUEUE_NAME);

    alarm_queue = mq_open(ALARM_QUEUE_NAME,
                          O_CREAT | O_RDWR,
                          0666,
                          &alarm_attr);

    if (alarm_queue == (mqd_t)-1) {
        perror("mq_open alarm_queue");
        return 1;
    }

    logger_queue = mq_open(LOGGER_QUEUE_NAME,
                           O_CREAT | O_RDWR,
                           0666,
                           &logger_attr);

    if (logger_queue == (mqd_t)-1) {
        perror("mq_open logger_queue");
        mq_close(alarm_queue);
        mq_unlink(ALARM_QUEUE_NAME);
        return 1;
    }

    if (circular_buffer_init(&buffer, BUFFER_CAPACITY) != 0) {
        fprintf(stderr, "Failed to initialize circular buffer\n");

        mq_close(logger_queue);
        mq_close(alarm_queue);
        mq_unlink(LOGGER_QUEUE_NAME);
        mq_unlink(ALARM_QUEUE_NAME);

        return 1;
    }

    sensor_config.buffer = &buffer;
    sensor_config.interval_ms = interval_ms;
    sensor_config.verbose = verbose;
    sensor_config.running = &stop_requested;

    processor_config.buffer = &buffer;
    processor_config.alarm_queue = alarm_queue;
    processor_config.logger_queue = logger_queue;
    processor_config.temperature_threshold = temperature_threshold;
    processor_config.humidity_threshold = humidity_threshold;
    processor_config.verbose = verbose;
    processor_config.running = &stop_requested;

    alert_config.alarm_queue = alarm_queue;
    alert_config.logger_queue = logger_queue;
    alert_config.verbose = verbose;
    alert_config.running = &stop_requested;

    logger_config.logger_queue = logger_queue;
    logger_config.log_path = "/tmp/sms.log";
    logger_config.verbose = verbose;
    logger_config.running = &stop_requested;

    printf("========================================\n");
    printf(" Sensor Monitoring System\n");
    printf("========================================\n");
    printf("Interval      : %d ms\n", interval_ms);
    printf("Temperature   : %d C\n", temperature_threshold);
    printf("Humidity      : %d %%\n", humidity_threshold);
    printf("Duration      : %d sec\n", duration_sec);
    printf("Buffer        : %d samples\n", BUFFER_CAPACITY);
    printf("Log           : %s\n", logger_config.log_path);
    printf("========================================\n");

    if (pthread_create(&logger_thread,
                       NULL,
                       logger_thread_func,
                       &logger_config) != 0) {
        perror("pthread_create logger");
        goto cleanup;
    }

    if (pthread_create(&alert_thread,
                       NULL,
                       alert_thread_func,
                       &alert_config) != 0) {
        perror("pthread_create alert");
        stop_requested = 1;
        pthread_join(logger_thread, NULL);
        goto cleanup;
    }

    if (pthread_create(&processor_thread,
                       NULL,
                       processor_thread_func,
                       &processor_config) != 0) {
        perror("pthread_create processor");
        stop_requested = 1;
        pthread_join(alert_thread, NULL);
        pthread_join(logger_thread, NULL);
        goto cleanup;
    }

    if (pthread_create(&sensor_thread,
                       NULL,
                       sensor_thread_func,
                       &sensor_config) != 0) {
        perror("pthread_create sensor");
        stop_requested = 1;
        pthread_join(processor_thread, NULL);
        pthread_join(alert_thread, NULL);
        pthread_join(logger_thread, NULL);
        goto cleanup;
    }

    for (int elapsed = 0;
         elapsed < duration_sec && !stop_requested;
         elapsed++) {
        sleep(1);
    }

    stop_requested = 1;

    /*
     * Wake the Processor Thread if it is blocked waiting
     * for data in the circular buffer.
     */
    circular_buffer_stop(&buffer);

    pthread_join(sensor_thread, NULL);
    pthread_join(processor_thread, NULL);
    pthread_join(alert_thread, NULL);
    pthread_join(logger_thread, NULL);

    printf("\n========================================\n");
    printf(" Shutdown complete\n");
    printf("========================================\n");

    printf("Produced       : %lu\n",
           circular_buffer_total_produced(&buffer));
    printf("Consumed       : %lu\n",
           circular_buffer_total_consumed(&buffer));
    printf("Buffer current : %zu\n",
           circular_buffer_current_size(&buffer));
    printf("Overflow       : %lu\n",
           circular_buffer_overflow_count(&buffer));

    printf("TEMP_HIGH      : %lu\n",
           alert_config.temp_high_count);
    printf("HUMID_HIGH     : %lu\n",
           alert_config.humid_high_count);
    printf("TEMP_SPIKE     : %lu\n",
           alert_config.temp_spike_count);

cleanup:
    circular_buffer_destroy(&buffer);

    if (logger_queue != (mqd_t)-1)
        mq_close(logger_queue);

    if (alarm_queue != (mqd_t)-1)
        mq_close(alarm_queue);

    mq_unlink(LOGGER_QUEUE_NAME);
    mq_unlink(ALARM_QUEUE_NAME);

    return 0;
}
