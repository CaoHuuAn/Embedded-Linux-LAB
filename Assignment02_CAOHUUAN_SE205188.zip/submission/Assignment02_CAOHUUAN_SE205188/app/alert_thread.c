#include "alert_thread.h"
#include "processor_thread.h"

#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#define ALERT_LOG_MESSAGE_SIZE 512

static int send_alert_log(mqd_t logger_queue,
                          const AlertMessage *message)
{
    char log_message[ALERT_LOG_MESSAGE_SIZE];
    int len;

    if (logger_queue == (mqd_t)-1 || message == NULL)
        return -1;

    switch (message->type) {
    case ALERT_TEMP_HIGH:
        len = snprintf(log_message,
                       sizeof(log_message),
                       "[ALERT][%llu] TEMP_HIGH: %.1f C\n",
                       message->timestamp_ms,
                       message->value);
        break;

    case ALERT_HUMID_HIGH:
        len = snprintf(log_message,
                       sizeof(log_message),
                       "[ALERT][%llu] HUMID_HIGH: %.1f %%\n",
                       message->timestamp_ms,
                       message->value);
        break;

    case ALERT_TEMP_SPIKE:
        len = snprintf(log_message,
                       sizeof(log_message),
                       "[ALERT][%llu] TEMP_SPIKE: %.1f -> %.1f C\n",
                       message->timestamp_ms,
                       message->previous_value,
                       message->value);
        break;

    default:
        return -1;
    }

    if (len < 0 || (size_t)len >= sizeof(log_message))
        return -1;

    if (mq_send(logger_queue,
                log_message,
                (size_t)len + 1,
                0) < 0) {
        return -1;
    }

    return 0;
}

void *alert_thread_func(void *arg)
{
    AlertThreadConfig *config = arg;

    if (config == NULL || config->running == NULL)
        return NULL;

    if (config->verbose)
        printf("[Alert] Started\n");

    while (!*(config->running)) {
        AlertMessage message;
        char receive_buffer[256];
        struct timespec timeout;
        ssize_t received;

        memset(&message, 0, sizeof(message));
        memset(receive_buffer, 0, sizeof(receive_buffer));

        /*
         * Timed receive prevents the thread from blocking forever
         * when the application is shutting down.
         */
        if (clock_gettime(CLOCK_REALTIME, &timeout) < 0) {
            perror("[Alert] clock_gettime");
            break;
        }

        timeout.tv_sec += 1;

        received = mq_timedreceive(config->alarm_queue,
                                   receive_buffer,
                                   sizeof(receive_buffer),
                                   NULL,
                                   &timeout);

        if (received < 0) {
            if (errno == ETIMEDOUT || errno == EINTR)
                continue;

            if (config->verbose)
                perror("[Alert] mq_timedreceive");

            if (!*(config->running))
                break;

            continue;
        }

        if ((size_t)received != sizeof(message))
            continue;

        memcpy(&message, receive_buffer, sizeof(message));

        switch (message.type) {
        case ALERT_TEMP_HIGH:
            config->temp_high_count++;

            printf("[ALERT][%llu] TEMP_HIGH: %.1f C\n",
                   message.timestamp_ms,
                   message.value);
            break;

        case ALERT_HUMID_HIGH:
            config->humid_high_count++;

            printf("[ALERT][%llu] HUMID_HIGH: %.1f %%\n",
                   message.timestamp_ms,
                   message.value);
            break;

        case ALERT_TEMP_SPIKE:
            config->temp_spike_count++;

            printf("[ALERT][%llu] TEMP_SPIKE: %.1f -> %.1f C\n",
                   message.timestamp_ms,
                   message.previous_value,
                   message.value);
            break;

        default:
            if (config->verbose) {
                fprintf(stderr,
                        "[Alert] Unknown alert type: %d\n",
                        message.type);
            }

            continue;
        }

        if (send_alert_log(config->logger_queue, &message) < 0) {
            if (config->verbose)
                perror("[Alert] mq_send logger");
        }
    }

    if (config->verbose)
        printf("[Alert] Stopped\n");

    return NULL;
}
