#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>

#include "../driver/sms_sensor.h"

int main(void)
{
    int fd;
    unsigned long interval_ms = 500;

    fd = open(SMS_DEVICE_PATH, O_RDONLY);
    if (fd < 0) {
        perror("open");
        return 1;
    }

    if (ioctl(fd, SMS_SET_INTERVAL, &interval_ms) < 0) {
        perror("ioctl SMS_SET_INTERVAL");
        close(fd);
        return 1;
    }

    printf("SMS_SET_INTERVAL = %lu ms: OK\n", interval_ms);

    close(fd);
    return 0;
}
