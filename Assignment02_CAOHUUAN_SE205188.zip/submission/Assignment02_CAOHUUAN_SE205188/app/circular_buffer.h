#ifndef CIRCULAR_BUFFER_H
#define CIRCULAR_BUFFER_H

#include <stddef.h>
#include <pthread.h>

typedef struct {
    unsigned long long timestamp_ms;
    float temperature;
    float humidity;
} SensorData;

typedef struct {
    SensorData *data;

    size_t capacity;
    size_t head;
    size_t tail;
    size_t size;

    int stopped;

    pthread_mutex_t mutex;
    pthread_cond_t not_empty;
    pthread_cond_t not_full;

    unsigned long total_produced;
    unsigned long total_consumed;
    unsigned long overflow_count;
} CircularBuffer;

int circular_buffer_init(CircularBuffer *cb, size_t capacity);
void circular_buffer_destroy(CircularBuffer *cb);

int circular_buffer_push(CircularBuffer *cb, const SensorData *item);
int circular_buffer_pop(CircularBuffer *cb, SensorData *item);

void circular_buffer_stop(CircularBuffer *cb);

size_t circular_buffer_current_size(CircularBuffer *cb);
unsigned long circular_buffer_total_produced(CircularBuffer *cb);
unsigned long circular_buffer_total_consumed(CircularBuffer *cb);
unsigned long circular_buffer_overflow_count(CircularBuffer *cb);

#endif
