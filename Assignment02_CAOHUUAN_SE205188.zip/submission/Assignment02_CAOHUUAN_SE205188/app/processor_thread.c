#include "processor_thread.h"

#include <errno.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#define ROLLING_WINDOW_SIZE 10
#define TEMP_SPIKE_THRESHOLD 5.0f

static void calculate_average(const SensorData *window,
                              size_t count,
                              float *average_temperature,
                              float *average_humidity)
{
    float temperature_sum = 0.0f;
    float humidity_sum = 0.0f;

    if (count == 0) {
        *average_temperature = 0.0f;
        *average_humidity = 0.0f;
        return;
    }

    for (size_t i = 0; i < count; i++) {
        temperature_sum += window[i].temperature;
        humidity_sum += window[i].humidity;
    }

    *average_temperature = temperature_sum / (float)count;
    *average_humidity = humidity_sum / (float)count;
}

static int send_alert(mqd_t alarm_queue,
                      int type,
                      const SensorData *current,
                      float previous_value)
{
    AlertMessage message;

    memset(&message, 0, sizeof(message));

    message.type = type;
    message.timestamp_ms = current->timestamp_ms;
    message.value = current->temperature;
    message.previous_value = previous_value;
    message.temperature = current->temperature;
    message.humidity = current->humidity;

    if (mq_send(alarm_queue,
                (const char *)&message,
                sizeof(message),
                0) < 0) {
        if (errno == EINTR)
            return 0;

        return -1;
    }

    return 0;
}

static int send_log_message(mqd_t logger_queue,
                            const SensorData *current,
                            float average_temperature,
                            float average_humidity)
{
    SensorLogMessage message;

    memset(&message, 0, sizeof(message));

    message.timestamp_ms = current->timestamp_ms;
    message.temperature = current->temperature;
    message.humidity = current->humidity;
    message.average_temperature = average_temperature;
    message.average_humidity = average_humidity;

    if (mq_send(logger_queue,
                (const char *)&message,
                sizeof(message),
                0) < 0) {
        if (errno == EINTR)
            return 0;

        return -1;
    }

    return 0;
}

void *processor_thread_func(void *arg)
{
    ProcessorThreadConfig *config = arg;

    SensorData window[ROLLING_WINDOW_SIZE];
    size_t window_count = 0;
    size_t window_index = 0;

    SensorData current;
    float previous_temperature = 0.0f;
    int have_previous_temperature = 0;

    if (config == NULL ||
        config->buffer == NULL ||
        config->running == NULL) {
        return NULL;
    }

    memset(window, 0, sizeof(window));

    if (config->verbose)
        printf("[Processor] Started\n");

    while (!*(config->running)) {
        float average_temperature;
        float average_humidity;

        if (circular_buffer_pop(config->buffer, &current) != 0)
            continue;

        if (window_count < ROLLING_WINDOW_SIZE) {
            window[window_count] = current;
            window_count++;
        } else {
            window[window_index] = current;
        }

        window_index = (window_index + 1) % ROLLING_WINDOW_SIZE;

        calculate_average(window,
                          window_count,
                          &average_temperature,
                          &average_humidity);

        if (config->verbose) {
            printf("[Processor] %llu ms: "
                   "T=%.1f C, H=%.1f %% | "
                   "AVG10: T=%.1f C, H=%.1f %%\n",
                   current.timestamp_ms,
                   current.temperature,
                   current.humidity,
                   average_temperature,
                   average_humidity);
        }

        if (current.temperature > config->temperature_threshold) {
            if (send_alert(config->alarm_queue,
                           ALERT_TEMP_HIGH,
                           &current,
                           previous_temperature) < 0) {
                if (config->verbose)
                    perror("[Processor] mq_send TEMP_HIGH");
            }
        }

        if (current.humidity > config->humidity_threshold) {
            if (send_alert(config->alarm_queue,
                           ALERT_HUMID_HIGH,
                           &current,
                           previous_temperature) < 0) {
                if (config->verbose)
                    perror("[Processor] mq_send HUMID_HIGH");
            }
        }

        if (have_previous_temperature &&
            fabsf(current.temperature - previous_temperature) >
                TEMP_SPIKE_THRESHOLD) {

            if (send_alert(config->alarm_queue,
                           ALERT_TEMP_SPIKE,
                           &current,
                           previous_temperature) < 0) {
                if (config->verbose)
                    perror("[Processor] mq_send TEMP_SPIKE");
            }
        }

        if (send_log_message(config->logger_queue,
                             &current,
                             average_temperature,
                             average_humidity) < 0) {
            if (config->verbose)
                perror("[Processor] mq_send logger");
        }

        previous_temperature = current.temperature;
        have_previous_temperature = 1;
    }

    if (config->verbose)
        printf("[Processor] Stopped\n");

    return NULL;
}
