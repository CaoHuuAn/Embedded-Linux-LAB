#include "logger_thread.h"
#include "processor_thread.h"

#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#define LOGGER_MESSAGE_SIZE 512
#define MAX_LOG_SIZE (1024 * 1024)
#define FLUSH_INTERVAL_SEC 5

static int rotate_log_if_needed(FILE **log_file,
                               const char *path)
{
    struct stat st;
    char rotated_path[512];

    if (log_file == NULL || *log_file == NULL || path == NULL)
        return -1;

    if (stat(path, &st) < 0) {
        if (errno == ENOENT)
            return 0;

        return -1;
    }

    if (st.st_size <= MAX_LOG_SIZE)
        return 0;

    if (snprintf(rotated_path,
                 sizeof(rotated_path),
                 "%s.1",
                 path) >= (int)sizeof(rotated_path)) {
        return -1;
    }

    if (fclose(*log_file) != 0)
        return -1;

    *log_file = NULL;

    /*
     * Remove the previous .1 file so that rename()
     * can create a fresh rotated log.
     */
    unlink(rotated_path);

    if (rename(path, rotated_path) < 0)
        return -1;

    *log_file = fopen(path, "a");

    if (*log_file == NULL)
        return -1;

    return 0;
}

static void write_sensor_log(FILE *log_file,
                             const SensorLogMessage *message)
{
    if (log_file == NULL || message == NULL)
        return;

    fprintf(log_file,
            "[SAMPLE][%llu] T=%.1f C, H=%.1f %% | "
            "AVG10: T=%.1f C, H=%.1f %%\n",
            message->timestamp_ms,
            message->temperature,
            message->humidity,
            message->average_temperature,
            message->average_humidity);
}

static void write_alert_log(FILE *log_file,
                            const char *message)
{
    if (log_file == NULL || message == NULL)
        return;

    fputs(message, log_file);
}

void *logger_thread_func(void *arg)
{
    LoggerThreadConfig *config = arg;
    FILE *log_file;
    time_t last_flush;

    if (config == NULL ||
        config->running == NULL ||
        config->log_path == NULL) {
        return NULL;
    }

    log_file = fopen(config->log_path, "a");

    if (log_file == NULL) {
        perror("[Logger] fopen");
        return NULL;
    }

    last_flush = time(NULL);

    if (config->verbose)
        printf("[Logger] Started: %s\n", config->log_path);

    while (!*(config->running)) {
        unsigned char message[LOGGER_MESSAGE_SIZE];
        struct timespec timeout;
        ssize_t received;

        memset(message, 0, sizeof(message));

        if (clock_gettime(CLOCK_REALTIME, &timeout) < 0) {
            perror("[Logger] clock_gettime");
            break;
        }

        timeout.tv_sec += 1;

        received = mq_timedreceive(config->logger_queue,
                                   (char *)message,
                                   sizeof(message),
                                   NULL,
                                   &timeout);

        if (received >= 0) {
            int is_sensor_message =
                ((size_t)received == sizeof(SensorLogMessage));

            if (rotate_log_if_needed(&log_file,
                                     config->log_path) < 0) {
                if (config->verbose)
                    fprintf(stderr,
                            "[Logger] Log rotation failed\n");
            } else if (is_sensor_message) {
                SensorLogMessage sensor_message;

                memcpy(&sensor_message,
                       message,
                       sizeof(sensor_message));

                write_sensor_log(log_file, &sensor_message);
                config->messages_logged++;
            } else {
                /*
                 * Alert messages are variable-length strings.
                 */
                message[received < LOGGER_MESSAGE_SIZE ?
                        received : LOGGER_MESSAGE_SIZE - 1] = '\0';

                write_alert_log(log_file,
                                (const char *)message);

                config->messages_logged++;
            }
        } else if (errno != ETIMEDOUT && errno != EINTR) {
            if (config->verbose)
                perror("[Logger] mq_timedreceive");
        }

        if (time(NULL) - last_flush >= FLUSH_INTERVAL_SEC) {
            fflush(log_file);
            last_flush = time(NULL);
        }
    }

    fflush(log_file);
    fclose(log_file);

    if (config->verbose)
        printf("[Logger] Stopped, messages=%lu\n",
               config->messages_logged);

    return NULL;
}
