#ifndef PROCESSOR_THREAD_H
#define PROCESSOR_THREAD_H

#include <mqueue.h>
#include <pthread.h>

#include "circular_buffer.h"

typedef struct {
    int type;

    unsigned long long timestamp_ms;

    float value;
    float previous_value;

    float temperature;
    float humidity;
} AlertMessage;

typedef struct {
    unsigned long long timestamp_ms;

    float temperature;
    float humidity;

    float average_temperature;
    float average_humidity;
} SensorLogMessage;

enum {
    ALERT_TEMP_HIGH = 1,
    ALERT_HUMID_HIGH = 2,
    ALERT_TEMP_SPIKE = 3
};

typedef struct {
    CircularBuffer *buffer;

    mqd_t alarm_queue;
    mqd_t logger_queue;

    int temperature_threshold;
    int humidity_threshold;
    int verbose;

    volatile int *running;
} ProcessorThreadConfig;

void *processor_thread_func(void *arg);

#endif
