#ifndef LOGGER_THREAD_H
#define LOGGER_THREAD_H

#include <mqueue.h>
#include <pthread.h>

typedef struct {
    mqd_t logger_queue;

    const char *log_path;

    int verbose;

    volatile int *running;

    unsigned long messages_logged;
} LoggerThreadConfig;

void *logger_thread_func(void *arg);

#endif
