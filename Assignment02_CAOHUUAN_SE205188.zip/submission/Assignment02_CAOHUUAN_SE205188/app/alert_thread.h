#ifndef ALERT_THREAD_H
#define ALERT_THREAD_H

#include <mqueue.h>
#include <pthread.h>

typedef struct {
    mqd_t alarm_queue;
    mqd_t logger_queue;

    int verbose;

    volatile int *running;

    unsigned long temp_high_count;
    unsigned long humid_high_count;
    unsigned long temp_spike_count;
} AlertThreadConfig;

void *alert_thread_func(void *arg);

#endif
