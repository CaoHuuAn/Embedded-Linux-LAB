/*
 * sms_sensor.h
 *
 * Purpose:
 *     Shared interface definitions for the SMS sensor driver
 *     and userspace application.
 *
 * Author: CAO HUU AN - SE205188
 * Date: 2026-10-27
 */

#ifndef SMS_SENSOR_H
#define SMS_SENSOR_H

#include <linux/ioctl.h>

#define SMS_DEVICE_PATH "/dev/sms_sensor"

/*
 * ioctl command:
 * Configure the minimum interval between two sensor reads.
 *
 * Argument:
 *     unsigned long interval_ms
 */
#define SMS_SET_INTERVAL _IOW('S', 1, unsigned long)

#endif /* SMS_SENSOR_H */
