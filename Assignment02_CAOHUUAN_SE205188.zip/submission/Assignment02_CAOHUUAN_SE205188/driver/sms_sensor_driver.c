/*
 * sms_sensor_driver.c
 *
 * Purpose:
 *     Embedded Linux Sensor Monitoring System character device driver.
 *
 * Author: CAO HUU AN - SE205188
 * Date: 2026-10-27
 */

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/uaccess.h>
#include <linux/mutex.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/random.h>
#include <linux/ktime.h>
#include <linux/slab.h>

#include "sms_sensor.h"

#define DRIVER_NAME "sms_sensor_driver"
#define DEVICE_NAME "sms_sensor"

#define DEFAULT_INTERVAL_MS 100

static dev_t sms_dev;
static struct cdev sms_cdev;
static struct class *sms_class;
static struct device *sms_device;
static struct proc_dir_entry *sms_proc_entry;
static const struct proc_ops sms_proc_fops;
static DEFINE_MUTEX(sms_mutex);

static unsigned long read_count;
static unsigned long long driver_start_ms;
static unsigned long long last_read_ms;

static unsigned int interval_ms = DEFAULT_INTERVAL_MS;

static int last_temperature_x10;
static int last_humidity_x10;
static int sms_open(struct inode *inode, struct file *file)
{
    pr_info("%s: device opened\n", DRIVER_NAME);
    return 0;
}

static int sms_release(struct inode *inode, struct file *file)
{
    pr_info("%s: device released\n", DRIVER_NAME);
    return 0;
}
static void sms_generate_sensor_data(void)
{
    u32 random_value;

    random_value = get_random_u32();
    last_temperature_x10 = 150 + (random_value % 301);

    random_value = get_random_u32();
    last_humidity_x10 = 300 + (random_value % 601);
}
static ssize_t sms_read(struct file *file,
                        char __user *buf,
                        size_t count,
                        loff_t *ppos)
{
    char data[128];
    int len;
    unsigned long long now_ms;
    unsigned long long elapsed_ms;

    mutex_lock(&sms_mutex);

    now_ms = ktime_to_ms(ktime_get());

    if (last_read_ms != 0) {
        elapsed_ms = now_ms - last_read_ms;

        if (elapsed_ms < interval_ms) {
            mutex_unlock(&sms_mutex);
            return -EAGAIN;
        }
    }

    sms_generate_sensor_data();

    last_read_ms = now_ms;
    read_count++;

    len = scnprintf(data, sizeof(data),
                    "%llu,%d.%d,%d.%d\n",
                    now_ms,
                    last_temperature_x10 / 10,
                    last_temperature_x10 % 10,
                    last_humidity_x10 / 10,
                    last_humidity_x10 % 10);

    mutex_unlock(&sms_mutex);

    if (count < len)
        return -EINVAL;

    if (copy_to_user(buf, data, len))
        return -EFAULT;

    *ppos += len;

    return len;
}
static long sms_ioctl(struct file *file,
                      unsigned int cmd,
                      unsigned long arg)
{
    unsigned long new_interval;

    switch (cmd) {
    case SMS_SET_INTERVAL:
        if (copy_from_user(&new_interval,
                           (unsigned long __user *)arg,
                           sizeof(new_interval)))
            return -EFAULT;

        if (new_interval == 0)
            return -EINVAL;

        mutex_lock(&sms_mutex);
        interval_ms = new_interval;
        mutex_unlock(&sms_mutex);

        pr_info("%s: interval set to %lu ms\n",
                DRIVER_NAME, new_interval);

        return 0;

    default:
        return -ENOTTY;
    }
}
static const struct file_operations sms_fops = {
    .owner = THIS_MODULE,
    .open = sms_open,
    .read = sms_read,
    .unlocked_ioctl = sms_ioctl,
    .release = sms_release,
};
static int __init sms_init(void)
{
    int ret;

    driver_start_ms = ktime_to_ms(ktime_get());
    last_read_ms = 0;
    read_count = 0;
    last_temperature_x10 = 0;
    last_humidity_x10 = 0;

    ret = alloc_chrdev_region(&sms_dev, 0, 1, DEVICE_NAME);
    if (ret < 0) {
        pr_err("%s: alloc_chrdev_region failed\n", DRIVER_NAME);
        return ret;
    }

    pr_info("%s: allocated major=%d minor=%d\n",
            DRIVER_NAME,
            MAJOR(sms_dev),
            MINOR(sms_dev));

    cdev_init(&sms_cdev, &sms_fops);
    sms_cdev.owner = THIS_MODULE;

    ret = cdev_add(&sms_cdev, sms_dev, 1);
    if (ret < 0) {
        pr_err("%s: cdev_add failed\n", DRIVER_NAME);
        unregister_chrdev_region(sms_dev, 1);
        return ret;
    }

    sms_class = class_create(DEVICE_NAME);
    if (IS_ERR(sms_class)) {
        ret = PTR_ERR(sms_class);
        pr_err("%s: class_create failed\n", DRIVER_NAME);
        cdev_del(&sms_cdev);
        unregister_chrdev_region(sms_dev, 1);
        return ret;
    }

    sms_device = device_create(sms_class,
                               NULL,
                               sms_dev,
                               NULL,
                               DEVICE_NAME);

    if (IS_ERR(sms_device)) {
        ret = PTR_ERR(sms_device);
        pr_err("%s: device_create failed\n", DRIVER_NAME);
        class_destroy(sms_class);
        cdev_del(&sms_cdev);
        unregister_chrdev_region(sms_dev, 1);
        return ret;
    }

    pr_info("%s: /dev/%s created\n",
            DRIVER_NAME, DEVICE_NAME);

    sms_proc_entry = proc_create("sms_stats",
                                 0444,
                                 NULL,
                                 &sms_proc_fops);

    if (!sms_proc_entry) {
        pr_err("%s: proc_create failed\n", DRIVER_NAME);
        device_destroy(sms_class, sms_dev);
        class_destroy(sms_class);
        cdev_del(&sms_cdev);
        unregister_chrdev_region(sms_dev, 1);
        return -ENOMEM;
    }

    pr_info("%s: /proc/sms_stats created\n", DRIVER_NAME);

    return 0;
}
static int sms_proc_show(struct seq_file *m, void *v)
{
    unsigned long long now_ms;
    unsigned long long uptime_ms;

    mutex_lock(&sms_mutex);

    now_ms = ktime_to_ms(ktime_get());
    uptime_ms = now_ms - driver_start_ms;

    seq_printf(m, "read_count: %lu\n", read_count);
    seq_printf(m, "last_temperature: %d.%d C\n",
               last_temperature_x10 / 10,
               last_temperature_x10 % 10);
    seq_printf(m, "last_humidity: %d.%d %%\n",
               last_humidity_x10 / 10,
               last_humidity_x10 % 10);
    do_div(uptime_ms, 1000);
    seq_printf(m, "driver_uptime: %llu s\n",
               uptime_ms);

    mutex_unlock(&sms_mutex);

    return 0;
}

static int sms_proc_open(struct inode *inode, struct file *file)
{
    return single_open(file, sms_proc_show, NULL);
}

static const struct proc_ops sms_proc_fops = {
    .proc_open = sms_proc_open,
    .proc_read = seq_read,
    .proc_lseek = seq_lseek,
    .proc_release = single_release,
};
static void __exit sms_exit(void)
{
    if (sms_proc_entry)
        proc_remove(sms_proc_entry);

    if (sms_device)
        device_destroy(sms_class, sms_dev);

    if (sms_class)
        class_destroy(sms_class);

    cdev_del(&sms_cdev);
    unregister_chrdev_region(sms_dev, 1);

    pr_info("%s: unloaded\n", DRIVER_NAME);
}

module_init(sms_init);
module_exit(sms_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("CAO HUU AN - SE205188");
MODULE_DESCRIPTION("Sensor Monitoring System character device driver");
MODULE_VERSION("1.0");
