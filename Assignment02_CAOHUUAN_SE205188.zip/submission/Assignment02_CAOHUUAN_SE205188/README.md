# Assignment 02 - Sensor Monitoring System

Student: CAO HUU AN
MSSV: SE205188

## Contents

- driver/ : Kernel sensor driver source and module
- app/ : Multi-threaded user-space application source and binaries
- logs/ : T1-T4 test, debugging, profiling, memory and jitter evidence
- output/ : Final ARM initramfs image
- bao_cao/ : Final project report

## Final Verification

- ARMv7/QEMU integration verified
- /dev/sms_sensor verified
- /proc/sms_stats verified
- 4 worker threads verified
- 60-second functional test completed
- Valgrind: 0 bytes definitely lost
- GDB: all required worker threads verified
- T4 jitter testing completed with SCHED_OTHER and SCHED_FIFO
- QEMU memory footprint remained stable
