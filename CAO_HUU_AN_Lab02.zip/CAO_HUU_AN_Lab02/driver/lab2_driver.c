#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/device.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/mutex.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Embedded Linux Lab");
MODULE_DESCRIPTION("LAB-02: Simple Character Device Driver");
MODULE_VERSION("1.0");

#define DEVICE_NAME   "lab2"
#define CLASS_NAME    "lab2_class"
#define BUFFER_SIZE   1024
#define DRIVER_MAJOR  240

static int major_number = DRIVER_MAJOR;

static char device_buffer[BUFFER_SIZE];
static int buffer_len;
static int open_count;

static struct class *lab2_class;
static struct device *lab2_device;
static struct proc_dir_entry *proc_entry;

static DEFINE_MUTEX(lab2_mutex);


/* ============================================================
 * CHARACTER DEVICE
 * ============================================================ */

/*
 * lab2_open()
 *
 * Called when userspace opens /dev/lab2.
 * Increment open_count while holding the mutex.
 */
static int lab2_open(struct inode *inode, struct file *file)
{
    mutex_lock(&lab2_mutex);

    open_count++;

    mutex_unlock(&lab2_mutex);

    pr_info("lab2_driver: device opened (count=%d)\n",
            open_count);

    return 0;
}


/*
 * lab2_release()
 *
 * Called when userspace closes /dev/lab2.
 */
static int lab2_release(struct inode *inode, struct file *file)
{
    pr_info("lab2_driver: device closed\n");

    return 0;
}


/*
 * lab2_read()
 *
 * Copy data from kernel buffer to userspace.
 *
 * copy_to_user() must be used instead of memcpy()
 * because the destination is a userspace address.
 */
static ssize_t lab2_read(struct file *file,
                         char __user *buf,
                         size_t len,
                         loff_t *offset)
{
    size_t available;
    size_t bytes_to_read;

    mutex_lock(&lab2_mutex);

    if (*offset >= buffer_len) {
        mutex_unlock(&lab2_mutex);
        return 0;
    }

    available = buffer_len - *offset;
    bytes_to_read = len;

    if (bytes_to_read > available)
        bytes_to_read = available;

    if (copy_to_user(buf,
                     device_buffer + *offset,
                     bytes_to_read)) {
        mutex_unlock(&lab2_mutex);

        pr_err("lab2_driver: copy_to_user failed\n");

        return -EFAULT;
    }

    *offset += bytes_to_read;

    mutex_unlock(&lab2_mutex);

    pr_info("lab2_driver: sent %zu bytes to user\n",
            bytes_to_read);

    return bytes_to_read;
}


/*
 * lab2_write()
 *
 * Copy data from userspace to kernel buffer.
 *
 * copy_from_user() must be used instead of memcpy()
 * because the source is a userspace address.
 */
static ssize_t lab2_write(struct file *file,
                          const char __user *buf,
                          size_t len,
                          loff_t *offset)
{
    size_t write_len;

    write_len = len;

    if (write_len >= BUFFER_SIZE) {
        write_len = BUFFER_SIZE - 1;

        pr_warn("lab2_driver: write too large, truncating\n");
    }

    mutex_lock(&lab2_mutex);

    if (copy_from_user(device_buffer,
                       buf,
                       write_len)) {
        mutex_unlock(&lab2_mutex);

        pr_err("lab2_driver: copy_from_user failed\n");

        return -EFAULT;
    }

    buffer_len = write_len;
    device_buffer[buffer_len] = '\0';

    mutex_unlock(&lab2_mutex);

    pr_info("lab2_driver: received %zu bytes: [%s]\n",
            write_len,
            device_buffer);

    return write_len;
}


/*
 * File operations table.
 */
static const struct file_operations lab2_fops = {
    .owner   = THIS_MODULE,
    .open    = lab2_open,
    .read    = lab2_read,
    .write   = lab2_write,
    .release = lab2_release,
};


/* ============================================================
 * PROCFS
 * ============================================================ */

/*
 * lab2_proc_show()
 *
 * Display driver statistics through:
 *
 *     /proc/lab2_info
 */
static int lab2_proc_show(struct seq_file *m, void *v)
{
    mutex_lock(&lab2_mutex);

    seq_printf(m, "LAB-02 Driver Statistics\n");
    seq_printf(m, "========================\n");

    seq_printf(m, "Driver name   : %s\n",
               DEVICE_NAME);

    seq_printf(m, "Major number  : %d\n",
               major_number);

    seq_printf(m, "Buffer size   : %d bytes\n",
               BUFFER_SIZE);

    seq_printf(m, "Data length   : %d bytes\n",
               buffer_len);

    seq_printf(m, "Open count    : %d\n",
               open_count);

    if (buffer_len > 0) {
        seq_printf(m, "Last data     : [%s]\n",
                   device_buffer);
    } else {
        seq_printf(m, "Last data     : [(empty)]\n");
    }

    mutex_unlock(&lab2_mutex);

    return 0;
}


/*
 * lab2_proc_open()
 *
 * Open callback for /proc/lab2_info.
 */
static int lab2_proc_open(struct inode *inode,
                          struct file *file)
{
    return single_open(file,
                       lab2_proc_show,
                       NULL);
}


/*
 * proc_ops table for /proc/lab2_info.
 */
static const struct proc_ops lab2_proc_fops = {
    .proc_open    = lab2_proc_open,
    .proc_read    = seq_read,
    .proc_lseek   = seq_lseek,
    .proc_release = single_release,
};


/* ============================================================
 * SYSFS
 * ============================================================ */

/*
 * Show current buffer length.
 *
 * /sys/class/lab2_class/lab2/buffer_len
 */
static ssize_t buffer_len_show(struct device *dev,
                               struct device_attribute *attr,
                               char *buf)
{
    int value;

    mutex_lock(&lab2_mutex);

    value = buffer_len;

    mutex_unlock(&lab2_mutex);

    return sysfs_emit(buf, "%d\n", value);
}


/*
 * Show number of times the device has been opened.
 *
 * /sys/class/lab2_class/lab2/open_count
 */
static ssize_t open_count_show(struct device *dev,
                               struct device_attribute *attr,
                               char *buf)
{
    int value;

    mutex_lock(&lab2_mutex);

    value = open_count;

    mutex_unlock(&lab2_mutex);

    return sysfs_emit(buf, "%d\n", value);
}


/*
 * Show the last data written to the driver.
 *
 * /sys/class/lab2_class/lab2/last_data
 */
static ssize_t last_data_show(struct device *dev,
                              struct device_attribute *attr,
                              char *buf)
{
    ssize_t ret;

    mutex_lock(&lab2_mutex);

    if (buffer_len > 0)
        ret = sysfs_emit(buf, "%s\n", device_buffer);
    else
        ret = sysfs_emit(buf, "(empty)\n");

    mutex_unlock(&lab2_mutex);

    return ret;
}


/*
 * Read-only sysfs attributes.
 */
static DEVICE_ATTR_RO(buffer_len);
static DEVICE_ATTR_RO(open_count);
static DEVICE_ATTR_RO(last_data);


/*
 * Attribute list.
 */
static struct attribute *lab2_attrs[] = {
    &dev_attr_buffer_len.attr,
    &dev_attr_open_count.attr,
    &dev_attr_last_data.attr,
    NULL,
};


/*
 * Sysfs attribute group.
 */
static const struct attribute_group lab2_attr_group = {
    .attrs = lab2_attrs,
};


/* ============================================================
 * MODULE INIT
 * ============================================================ */

/*
 * lab2_init()
 *
 * Module initialization sequence:
 *
 * 1. register_chrdev()
 * 2. class_create()
 * 3. device_create()
 * 4. sysfs_create_group()
 * 5. proc_create()
 */
static int __init lab2_init(void)
{
    int ret;

    pr_info("lab2_driver: initializing module\n");

    /* Register character device. */
    ret = register_chrdev(major_number,
                          DEVICE_NAME,
                          &lab2_fops);

    if (ret < 0) {
        pr_err("lab2_driver: register_chrdev failed: %d\n",
               ret);

        return ret;
    }

    /* Create device class. */
    lab2_class = class_create(CLASS_NAME);

    if (IS_ERR(lab2_class)) {
        ret = PTR_ERR(lab2_class);

        unregister_chrdev(major_number,
                         DEVICE_NAME);

        pr_err("lab2_driver: class_create failed: %d\n",
               ret);

        return ret;
    }

    /* Create device. */
    lab2_device = device_create(lab2_class,
                                NULL,
                                MKDEV(major_number, 0),
                                NULL,
                                DEVICE_NAME);

    if (IS_ERR(lab2_device)) {
        ret = PTR_ERR(lab2_device);

        class_destroy(lab2_class);

        unregister_chrdev(major_number,
                         DEVICE_NAME);

        pr_err("lab2_driver: device_create failed: %d\n",
               ret);

        return ret;
    }

    /* Create sysfs attributes. */
    ret = sysfs_create_group(&lab2_device->kobj,
                             &lab2_attr_group);

    if (ret) {
        pr_err("lab2_driver: sysfs_create_group failed: %d\n",
               ret);

        device_destroy(lab2_class,
                       MKDEV(major_number, 0));

        class_destroy(lab2_class);

        unregister_chrdev(major_number,
                         DEVICE_NAME);

        return ret;
    }

    /* Create /proc/lab2_info. */
    proc_entry = proc_create("lab2_info",
                             0444,
                             NULL,
                             &lab2_proc_fops);

    if (!proc_entry) {
        pr_err("lab2_driver: failed to create /proc/lab2_info\n");

        sysfs_remove_group(&lab2_device->kobj,
                           &lab2_attr_group);

        device_destroy(lab2_class,
                       MKDEV(major_number, 0));

        class_destroy(lab2_class);

        unregister_chrdev(major_number,
                         DEVICE_NAME);

        return -ENOMEM;
    }

    pr_info("lab2_driver: /proc/lab2_info created\n");

    pr_info("lab2_driver: loaded, major=%d\n",
            major_number);

    return 0;
}


/* ============================================================
 * MODULE EXIT
 * ============================================================ */

/*
 * lab2_exit()
 *
 * Remove all resources in reverse order.
 */
static void __exit lab2_exit(void)
{
    if (proc_entry)
        proc_remove(proc_entry);

    sysfs_remove_group(&lab2_device->kobj,
                       &lab2_attr_group);

    device_destroy(lab2_class,
                   MKDEV(major_number, 0));

    class_destroy(lab2_class);

    unregister_chrdev(major_number,
                     DEVICE_NAME);

    pr_info("lab2_driver: module unloaded\n");
}


module_init(lab2_init);
module_exit(lab2_exit);
